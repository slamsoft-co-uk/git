package com.bao.codetest.elevator.process;

import org.junit.Test;

import java.util.Arrays;
import com.bao.codetest.elevator.enums.Direction;
import static com.bao.codetest.elevator.enums.Direction.UP;
import static org.junit.Assert.assertTrue;

public class FloorCmdTest {

    @Test
    public void testFloorCmdPopulation() {

        final Integer[] startAndEndFloors = new Integer[]{3,4};
        final Integer controlNumber = 3;
        final Direction direction = UP;

        FloorCmd floorCmd = new FloorCmd(startAndEndFloors[0], startAndEndFloors[1], controlNumber, direction);

        assertTrue(Arrays.equals(startAndEndFloors, floorCmd.getStartEndFloors()));
        assertTrue(controlNumber.equals(floorCmd.getControlNumber()));
        assertTrue(direction.equals(floorCmd.getCurrentDirection()));

    }

}
