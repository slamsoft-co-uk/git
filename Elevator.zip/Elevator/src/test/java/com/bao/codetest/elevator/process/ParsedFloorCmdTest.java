package com.bao.codetest.elevator.process;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static com.bao.codetest.elevator.enums.Direction.*;
import static org.junit.Assert.assertTrue;

public class ParsedFloorCmdTest {

    @Before
    public void setup() {
        FloorCmdFactory.reset();
    }

    @Test
    public void testScenarioSingleFloorCmd() {

        List<FloorCmd> expected = new ArrayList<>();
        expected.add(new FloorCmd(8, 1, 0, DOWN));

        ParsedFloorCmd pfc1 = new ParsedFloorCmd("10:8-1");
        assertTrue(pfc1.getInitialFloor().equals(10));
        assertTrue(pfc1.getStartAndEndFloors().size() == 1);
        assertTrue(pfc1.getStartAndEndFloors().equals(expected));

    }

    @Test
    public void testScenarioMultipleFloorCommands() {

        List<FloorCmd> expected = new ArrayList<>();
        expected.add(new FloorCmd(8, 1, 0, DOWN));
        expected.add(new FloorCmd(5, 6, 1, UP));
        expected.add(new FloorCmd(7, 3, 2, DOWN));
        expected.add(new FloorCmd(2, 5, 3, UP));

        ParsedFloorCmd pfc1 = new ParsedFloorCmd("6:8-1,5-6,7-3,2-5");
        assertTrue(pfc1.getInitialFloor().equals(6));
        assertTrue(pfc1.getStartAndEndFloors().size() == 4);
        assertTrue(pfc1.getStartAndEndFloors().equals(expected));

    }

    @Test(expected = NumberFormatException.class)
    public void testIncorrectStartingFloor() {
        new ParsedFloorCmd("x;8-1,5-6,7-3,2-5");
    }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void testIncorrectFloorCommands() {
        new ParsedFloorCmd("5:85");
    }

    @Test(expected = NumberFormatException.class)
    public void testAnyOldRubbish() {
        new ParsedFloorCmd("x12-12-89-12-x49");
    }


}
