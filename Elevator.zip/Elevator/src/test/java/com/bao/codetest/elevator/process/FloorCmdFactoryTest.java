package com.bao.codetest.elevator.process;

import org.junit.Before;
import org.junit.Test;

import static com.bao.codetest.elevator.enums.Direction.*;
import static org.junit.Assert.assertTrue;

public class FloorCmdFactoryTest {

    @Before
    public void setup() {
        FloorCmdFactory.reset();
    }

    @Test
    public void checkFloorCommandsScenario() {

        FloorCmd f1 = FloorCmdFactory.getInstance(3,4);
        FloorCmd f2 = FloorCmdFactory.getInstance(5,6);
        FloorCmd f3 = FloorCmdFactory.getInstance(7,8);
        FloorCmd f4 = FloorCmdFactory.getInstance(5,3);
        FloorCmd f5 = FloorCmdFactory.getInstance(6,2);
        FloorCmd f6 = FloorCmdFactory.getInstance(4,7);

        assertTrue(f1.getControlNumber().equals(0));
        assertTrue(f1.getCurrentDirection() == UP);

        assertTrue(f2.getControlNumber().equals(0));
        assertTrue(f2.getCurrentDirection() == UP);

        assertTrue(f3.getControlNumber().equals(0));
        assertTrue(f3.getCurrentDirection() == UP);

        assertTrue(f4.getControlNumber().equals(1));
        assertTrue(f4.getCurrentDirection() == DOWN);

        assertTrue(f5.getControlNumber().equals(1));
        assertTrue(f5.getCurrentDirection() == DOWN);

        assertTrue(f6.getControlNumber().equals(2));
        assertTrue(f6.getCurrentDirection() == UP);

    }
}