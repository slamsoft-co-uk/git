package com.bao.codetest.elevator.comparators;

import org.junit.Test;

import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

import static com.bao.codetest.elevator.enums.Direction.*;
import static org.junit.Assert.assertTrue;

public class FloorCmdComparatorTest {

    @Test
    public void testIntegersAscending() {

        Set<Integer> results = new TreeSet<>(new FloorCmdComparator(UP));
        results.addAll(Arrays.asList(3,2,5,1,3));

        Integer[] actual = new Integer[5];
        actual = results.toArray(actual);

        assertTrue((actual[0]).equals(1));
        assertTrue((actual[1]).equals(2));
        assertTrue((actual[2]).equals(3));
        assertTrue((actual[3]).equals(5));

    }

    @Test
    public void testIntegersDescending() {

        Set<Integer> results = new TreeSet<>(new FloorCmdComparator(DOWN));
        results.addAll(Arrays.asList(3,2,5,1,3));

        Integer[] actual = new Integer[5];
        actual = results.toArray(actual);

        assertTrue((actual[0]).equals(5));
        assertTrue((actual[1]).equals(3));
        assertTrue((actual[2]).equals(2));
        assertTrue((actual[3]).equals(1));

    }

}
