package com.bao.codetest.elevator.services;

import org.junit.Test;
import com.bao.codetest.elevator.service.AbstractConvertMode;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.assertTrue;

public class AbstractConvertModeTest extends AbstractConvertMode {

    @Test
    public void testInput1() {
        assertTrue(new AbstractConvertModeTest().produceOutputString(10, new ArrayList<>(Arrays.asList(8,1))).equals("10 8 1 (9)"));
    }

    @Test
    public void testInput2() {
        assertTrue(new AbstractConvertModeTest().produceOutputString(9, new ArrayList<>(Arrays.asList(1,5,1,6,1,5))).equals("9 1 5 1 6 1 5 (30)"));
    }

    @Test
    public void testInput3() {
        assertTrue(new AbstractConvertModeTest().produceOutputString(2, new ArrayList<>(Arrays.asList(4,1,4,2,6,8))).equals("2 4 1 4 2 6 8 (16)"));
    }

    @Test
    public void testInput4() {
        assertTrue(new AbstractConvertModeTest().produceOutputString(3, new ArrayList<>(Arrays.asList(7,9,3,7,5,8,7,11,11,1))).equals("3 7 9 3 7 5 8 7 11 1 (36)"));
    }

    @Test
    public void testInput5() {
        assertTrue(new AbstractConvertModeTest().produceOutputString(7, new ArrayList<>(Arrays.asList(11,6,10,5,6,8,7,4,12,7,8,9))).equals("7 11 6 10 5 6 8 7 4 12 7 8 9 (40)"));
    }

    @Test
    public void testInput6() {
        assertTrue(new AbstractConvertModeTest().produceOutputString(6, new ArrayList<>(Arrays.asList(1,8,6,8))).equals("6 1 8 6 8 (16)"));
    }

}