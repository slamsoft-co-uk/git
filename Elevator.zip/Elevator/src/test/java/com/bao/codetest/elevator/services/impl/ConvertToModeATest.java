package com.bao.codetest.elevator.services.impl;

import com.bao.codetest.elevator.process.FloorCmdFactory;
import com.bao.codetest.elevator.process.ParsedFloorCmd;
import com.bao.codetest.elevator.service.impl.ConvertToModeA;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ConvertToModeATest {

    @Before
    public void setup() {
        FloorCmdFactory.reset();
    }

    @Test
    public void testInput1() {
        String expected = "10 8 1 (9)";
        String actual = new ConvertToModeA().returnResults(new ParsedFloorCmd("10:8-1"));
        assertEquals(expected, actual);
    }

    @Test
    public void testInput2() {
        String expected = "9 1 5 1 6 1 5 (30)";
        String actual = new ConvertToModeA().returnResults(new ParsedFloorCmd("9:1-5,1-6,1-5"));
        assertEquals(expected, actual);
    }

    @Test
    public void testInput3() {
        String expected = "2 4 1 4 2 6 8 (16)";
        String actual = new ConvertToModeA().returnResults(new ParsedFloorCmd("2:4-1,4-2,6-8"));
        assertEquals(expected, actual);
    }

    @Test
    public void testInput4() {
        String expected = "3 7 9 3 7 5 8 7 11 1 (36)";
        String actual = new ConvertToModeA().returnResults(new ParsedFloorCmd("3:7-9,3-7,5-8,7-11,11-1"));
        assertEquals(expected, actual);
    }

    @Test
    public void testInput5() {
        String expected = "7 11 6 10 5 6 8 7 4 12 7 8 9 (40)";
        String actual = new ConvertToModeA().returnResults(new ParsedFloorCmd("7:11-6,10-5,6-8,7-4,12-7,8-9"));
        assertEquals(expected, actual);
    }

    @Test
    public void testInput6() {
        String expected = "6 1 8 6 8 (16)";
        String actual = new ConvertToModeA().returnResults(new ParsedFloorCmd("6:1-8,6-8"));
        assertEquals(expected, actual);
    }

}
