package com.bao.codetest.elevator.main;

import org.junit.Before;
import org.junit.Test;

import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;

public class GoElevatorTest {

    ///////////////////////////////////
    // Eyeball-only test...
    ///////////////////////////////////

    private String fullFileName = null;

    @Before
    public void setup() throws URISyntaxException {

        URL resource = getClass().getClassLoader().getResource("batch_commands.txt");

        if (resource != null) {
            fullFileName = Paths.get(resource.toURI()).toAbsolutePath().toString();
        }

    }

    @Test
    public void runProcessModeA() {

        System.out.println("Mode A");
        GoElevator.main(new String[]{fullFileName, "A"});

    }

    @Test
    public void runProcessModeB() {

        System.out.println("Mode B");
        GoElevator.main(new String[]{fullFileName, "B"});

    }

}