package com.bao.codetest.elevator.comparators;

import com.bao.codetest.elevator.enums.Direction;

import java.util.Comparator;

import static com.bao.codetest.elevator.enums.Direction.DOWN;

public class FloorCmdComparator implements Comparator<Integer> {

    private final Direction direction;

    public FloorCmdComparator(Direction direction) {
        this.direction = direction;
    }

    @Override
    public int compare(Integer o1, Integer o2) {
        return (o1>o2 ? 1 : o1<o2 ? -1 : 0) * (DOWN == direction ? -1 : 1);
    }

}
