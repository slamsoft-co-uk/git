package com.bao.codetest.elevator.enums;

public enum ElevatorMode {

    MODE_A ("A"),
    MODE_B ("B");

    ElevatorMode(String name) {}

}
