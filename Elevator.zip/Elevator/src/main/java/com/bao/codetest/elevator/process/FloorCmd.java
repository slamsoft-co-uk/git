package com.bao.codetest.elevator.process;

import com.bao.codetest.elevator.enums.Direction;
import com.google.common.base.Objects;

public class FloorCmd {

    private final Integer startFloor;
    private final Integer endFloor;
    private final Integer controlNumber;
    private final Direction currentDirection;

    public FloorCmd(Integer startFloor, Integer endFloor, Integer controlNumber, Direction currentDirection) {
        this.startFloor = startFloor;
        this.endFloor = endFloor;
        this.controlNumber = controlNumber;
        this.currentDirection = currentDirection;
    }

    public Integer[] getStartEndFloors() {
        return new Integer[]{startFloor, endFloor};
    }

    public Integer getControlNumber() {
        return controlNumber;
    }

    public Direction getCurrentDirection() {
        return currentDirection;
    }

    @Override
    public boolean equals(Object o) {

        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FloorCmd floorCmd = (FloorCmd) o;

        return Objects.equal(startFloor, floorCmd.startFloor)
                && Objects.equal(endFloor, floorCmd.endFloor)
                && Objects.equal(controlNumber, floorCmd.controlNumber)
                && Objects.equal(currentDirection, floorCmd.currentDirection);

    }

    @Override
    public int hashCode() {
        return Objects.hashCode(startFloor, endFloor, controlNumber, currentDirection);
    }
}