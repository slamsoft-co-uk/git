package com.bao.codetest.elevator.service.impl;

import com.bao.codetest.elevator.comparators.FloorCmdComparator;
import com.bao.codetest.elevator.process.FloorCmd;
import com.bao.codetest.elevator.process.ParsedFloorCmd;
import com.bao.codetest.elevator.service.AbstractConvertMode;

import java.util.*;
import java.util.stream.Collectors;

public class ConvertToModeB extends AbstractConvertMode{

    public String returnResults(ParsedFloorCmd parsedFloorCmd) {

        List<Integer> floorsToVisit = new ArrayList<>();
        Map<Integer, List<FloorCmd>> floorsMap = parsedFloorCmd.getStartAndEndFloors().stream().collect(Collectors.groupingBy(FloorCmd::getControlNumber));

        for (List<FloorCmd> floorCmdList : floorsMap.values()) {
            Set<Integer> floors = new TreeSet<>(new FloorCmdComparator(floorCmdList.get(0).getCurrentDirection()));
            for(FloorCmd floorCmd : floorCmdList) floors.addAll(Arrays.asList(floorCmd.getStartEndFloors()));
            floorsToVisit.addAll(floors);
        }

        return produceOutputString(parsedFloorCmd.getInitialFloor(), floorsToVisit);

    }
}
