package com.bao.codetest.elevator.process;

import com.bao.codetest.elevator.enums.Direction;

import static com.bao.codetest.elevator.enums.Direction.*;

public class FloorCmdFactory {

    private static Direction lastDirection = STARTING_POSITION;
    private static Integer currentControlNumber = 0;

    private FloorCmdFactory() { }

    public synchronized static FloorCmd getInstance(Integer startFloor, Integer endFloor) {

        Direction currentDirection = (startFloor > endFloor) ? DOWN : UP;

        if ((STARTING_POSITION != lastDirection) && (lastDirection != currentDirection)) {
            currentControlNumber++;
        }

        lastDirection = currentDirection;
        return new FloorCmd(startFloor, endFloor, currentControlNumber, currentDirection);

    }

    public synchronized static void reset() {
        lastDirection = STARTING_POSITION;
        currentControlNumber = 0;
    }

}
