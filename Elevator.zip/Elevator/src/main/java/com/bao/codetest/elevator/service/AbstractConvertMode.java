package com.bao.codetest.elevator.service;

import java.util.List;
import java.util.Objects;

public abstract class AbstractConvertMode {

    protected String produceOutputString(Integer initialFloor, List<Integer> remainingFloors) {

        StringBuilder outString = new StringBuilder(initialFloor.toString());

        Integer previousFloor = initialFloor;
        Integer totalFloors = 0;

        // remove duplicate values where they sit adjacent to one another.

        for (Integer currentFloor : remainingFloors) {
            if (!Objects.equals(currentFloor, previousFloor)) {
                outString.append(" ").append(currentFloor);
                totalFloors+=Math.abs(previousFloor - currentFloor);
                previousFloor = currentFloor;
            }
        }

        return outString.append(" (").append(totalFloors).append(")").toString();

    }

}
