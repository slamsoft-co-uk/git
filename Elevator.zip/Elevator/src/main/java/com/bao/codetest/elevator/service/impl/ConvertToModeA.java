package com.bao.codetest.elevator.service.impl;

import com.bao.codetest.elevator.process.FloorCmd;
import com.bao.codetest.elevator.process.ParsedFloorCmd;
import com.bao.codetest.elevator.service.AbstractConvertMode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ConvertToModeA extends AbstractConvertMode{

    public String returnResults(ParsedFloorCmd parsedFloorCmd) {
        List<Integer> floorsToVisit = new ArrayList<>();
        for(FloorCmd f: parsedFloorCmd.getStartAndEndFloors()) floorsToVisit.addAll(Arrays.asList(f.getStartEndFloors()));
        return produceOutputString(parsedFloorCmd.getInitialFloor(), floorsToVisit);
    }
}
