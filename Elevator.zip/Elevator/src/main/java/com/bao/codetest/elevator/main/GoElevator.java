package com.bao.codetest.elevator.main;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidParameterException;
import java.util.stream.Stream;
import com.bao.codetest.elevator.enums.ElevatorMode;
import com.bao.codetest.elevator.process.ParsedFloorCmd;
import com.bao.codetest.elevator.service.impl.ConvertToModeA;
import com.bao.codetest.elevator.service.impl.ConvertToModeB;

import static com.bao.codetest.elevator.enums.ElevatorMode.MODE_A;
import static com.bao.codetest.elevator.enums.ElevatorMode.MODE_B;

class GoElevator {

    private static String fileName = null;
    private static ElevatorMode elevatorMode = null;

    public static void main(String args[]) {

        if (args.length != 2) {
            throw new InvalidParameterException("GoElevator usage: [batch file name] [elevator mode]");
        }

        fileName = args[0];

        switch (args[1]) {
            case "A":
            default:
                elevatorMode = MODE_A;
                break;
            case "B":
                elevatorMode = MODE_B;
                break;
        }

        new GoElevator().processBatchFile();
    }

    private void processBatchFile() {
        try (Stream<String> stream = Files.lines(Paths.get(fileName))) {
            stream.forEach(this::processLineCommand);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void processLineCommand(String lineCommand) {

        ParsedFloorCmd parsedFloorCmd = new ParsedFloorCmd(lineCommand);

        if (elevatorMode == MODE_A) {
            System.out.println(new ConvertToModeA().returnResults(parsedFloorCmd));
        } else {
            System.out.println(new ConvertToModeB().returnResults(parsedFloorCmd));
        }

    }

}
