package com.bao.codetest.elevator.process;

import com.google.common.base.CharMatcher;
import com.google.common.base.Splitter;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

public class ParsedFloorCmd {

    private Integer initialFloor;
    private List<FloorCmd> startAndEndFloors;

    public ParsedFloorCmd(String floorCommands) {
        process(floorCommands);
    }

    private void process(String floorCommands) {
        List<String> orders = Splitter.on(CharMatcher.anyOf(",:")).splitToList(floorCommands);

        initialFloor = Integer.valueOf(orders.get(0));

        startAndEndFloors = new CopyOnWriteArrayList<>(
                orders.subList(1, orders.size()).stream()
                .map(x -> x.split("-"))
                .map(a -> FloorCmdFactory.getInstance(Integer.valueOf(a[0]), Integer.valueOf(a[1])))
                .collect(Collectors.toList()));

    }

    public Integer getInitialFloor() {
        return initialFloor;
    }

    public List<FloorCmd> getStartAndEndFloors() {
        return startAndEndFloors;
    }

}
