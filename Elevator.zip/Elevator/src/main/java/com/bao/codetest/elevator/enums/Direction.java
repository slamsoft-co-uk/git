package com.bao.codetest.elevator.enums;

public enum Direction {
    UP,
    DOWN,
    STARTING_POSITION
}
